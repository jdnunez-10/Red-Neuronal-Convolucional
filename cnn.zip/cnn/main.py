import numpy as np
from src.modelo import CNNMinima
from entrenamiento import EntrenadorCNN
from dataset.dataset import CargadorDataset
from src.funcionesPerdida import funcion_perdida_crossentropy, derivada_crossentropy


if __name__ == "__main__":

    # ------------------------------------------------------------
    # 1. CARGAR DATASET
    # ------------------------------------------------------------
    ruta_dataset = "dataset/"   # Directorio donde están tus carpetas por clase

    print("Cargando dataset real...")
    cargador = CargadorDataset(ruta_dataset, tamaño=(700, 600))
    X, y, mapa_clases = cargador.cargar_dataset()

    print("Mapa de clases detectado:", mapa_clases)

    X_train, y_train, X_test, y_test = cargador.dividir_train_test(X, y)

    print(f"Imágenes de entrenamiento: {X_train.shape}")
    print(f"Imágenes de prueba: {X_test.shape}")


    # ------------------------------------------------------------
    # 2. CREAR MODELO CNN
    # ------------------------------------------------------------
    print("\nConstruyendo CNN...")
    modelo = CNNMinima(
        tamaño_entrada=(1, 700, 600),
        num_clases=len(mapa_clases)
    )


    # ------------------------------------------------------------
    # 3. CONFIGURAR ENTRENADOR
    # ------------------------------------------------------------
    entrenador = EntrenadorCNN(
        modelo=modelo,
        lr=0.001,
        funcion_perdida=funcion_perdida_crossentropy,
        derivada_funcion_perdida=derivada_crossentropy
    )


    # ------------------------------------------------------------
    # 4. ENTRENAMIENTO
    # ------------------------------------------------------------
    print("\nEntrenando modelo...")

    entrenador.entrenar(
        X_train,
        y_train,
        epochs=10,
        lote_size=8
    )


    # ------------------------------------------------------------
    # 5. GUARDAR PESOS
    # ------------------------------------------------------------
    modelo.guardar_pesos("pesos_finales.pkl")
    print("\nEntrenamiento completado. Pesos guardados.")

