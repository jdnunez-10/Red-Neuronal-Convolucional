import numpy as np

class EntropiaCruzada:
    """
    Implementación manual de la pérdida Cross-Entropy
    usada para clasificación multiclase.
    """

    def calcular(self, prediccion, etiqueta_real):
        """
        prediccion: vector softmax (salida de la red)
        etiqueta_real: índice entero de la clase correcta
        """
        return -np.log(prediccion[etiqueta_real] + 1e-15)

    def gradiente(self, prediccion, etiqueta_real):
        """
        Derivada de la entropía cruzada respecto a softmax.
        """
        grad = prediccion.copy()
        grad[etiqueta_real] -= 1
        return grad
