import numpy as np
from src.capas.capaConvolucional import CapaConvolucional
from src.capas.capaPooling import CapaMaxPooling2x2
from src.capas.capaAplanada import CapaAplanada
from src.capas.capaTotalmenteConectada import CapaTotalmenteConectada
from src.activaciones import ReLU, Softmax

class CNNMinima:
    """
    Red Neuronal Convolucional mínima programada desde cero.
    Arquitectura:
        Conv → ReLU → Pool
        Conv → ReLU → Pool
        Flatten
        FC → ReLU
        FC → Softmax
    """

    def __init__(self, tamaño_entrada=(1,700,600), num_clases=5, lr=1e-3, umbral=0.6):
        C, H, W = tamaño_entrada
        self.lr = lr
        self.umbral = umbral

        # ------- CAPA 1 -------
        self.conv1 = CapaConvolucional(C, 8, 5, padding=2)
        self.relu1 = ReLU()
        self.pool1 = CapaMaxPooling2x2()

        # ------- CAPA 2 -------
        self.conv2 = CapaConvolucional(8, 16, 5, padding=2)
        self.relu2 = ReLU()
        self.pool2 = CapaMaxPooling2x2()

        # ------- CAPAS FINALES -------
        self.flatten = CapaAplanada()

        # Calcular tamaño del vector aplanado
        dummy = np.zeros((1, C, H, W))
        x = self.pool1.forward(self.relu1.forward(self.conv1.forward(dummy)))
        x = self.pool2.forward(self.relu2.forward(self.conv2.forward(x)))
        x = self.flatten.forward(x)
        tamaño_flat = x.shape[1]

        # Capa totalmente conectada
        self.fc1 = CapaTotalmenteConectada(tamaño_flat, 64)
        self.relu_fc = ReLU()

        # Capa de salida
        self.fc2 = CapaTotalmenteConectada(64, num_clases)
        self.softmax = Softmax()

    # --------------------------------------------------
    #                   FORWARD
    # --------------------------------------------------
    def forward(self, X):
        x = self.conv1.forward(X)
        x = self.relu1.forward(x)
        x = self.pool1.forward(x)

        x = self.conv2.forward(x)
        x = self.relu2.forward(x)
        x = self.pool2.forward(x)

        x = self.flatten.forward(x)

        x = self.fc1.forward(x)
        x = self.relu_fc.forward(x)

        logits = self.fc2.forward(x)
        return logits  # Softmax se aplica fuera

    # --------------------------------------------------
    #                 PREDICCIÓN
    # --------------------------------------------------
    def predecir_con_umbral(self, X):
        """
        Devuelve la clase predicha o 'ninguna' si la probabilidad máxima
        no supera el umbral definido.
        """
        logits = self.forward(X)
        probs = self.softmax.forward(logits)

        pred_indices = np.argmax(probs, axis=1)
        pred_vals = np.max(probs, axis=1)

        etiquetas_finales = []
        for p, m in zip(pred_indices, pred_vals):
            if m < self.umbral:
                etiquetas_finales.append("ninguna")
            else:
                etiquetas_finales.append(int(p))

        return etiquetas_finales, probs
