import numpy as np

class EntrenadorCNN:
    """
    Controlador del entrenamiento de la red neuronal.
    Implementa forward, backward y actualización de pesos.
    """

    def __init__(self, modelo, lr, funcion_perdida, derivada_funcion_perdida):
        self.modelo = modelo
        self.lr = lr
        self.funcion_perdida = funcion_perdida
        self.derivada_perdida = derivada_funcion_perdida

    def entrenar(self, X, y, epochs=5, lote_size=8):
        """
        X: imágenes normalizadas (N, C, H, W)
        y: etiquetas enteras (N,)
        lote_size: tamaño del batch
        """

        num_muestras = X.shape[0]

        for epoca in range(epochs):
            print(f"\n=== Época {epoca+1}/{epochs} ===")

            # Mezclar dataset cada época
            indices = np.arange(num_muestras)
            np.random.shuffle(indices)
            X = X[indices]
            y = y[indices]

            perdida_total = 0

            # Entrenamiento por lotes
            for i in range(0, num_muestras, lote_size):
                X_lote = X[i:i+lote_size]
                y_lote = y[i:i+lote_size]

                # Forward completo
                logits = self.modelo.forward(X_lote)

                # Calcular pérdida
                perdida = self.funcion_perdida(logits, y_lote)
                perdida_total += perdida

                # Calcular gradiente de la pérdida
                gradiente = self.derivada_perdida(logits, y_lote)

                # Backpropagation a través del modelo
                self.modelo.backward(gradiente, self.lr)

            print(f"Pérdida promedio: {perdida_total / (num_muestras // lote_size)}")
